<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_INFORMATION_TITLE', 'Information');
  define('MODULE_BOXES_INFORMATION_DESCRIPTION', 'Show information page links');
  define('MODULE_BOXES_INFORMATION_BOX_TITLE', 'Information');
  define('MODULE_BOXES_INFORMATION_BOX_PRIVACY', 'Privacy Notice');
  define('MODULE_BOXES_INFORMATION_BOX_CONDITIONS', 'Conditions of Use');
  define('MODULE_BOXES_INFORMATION_BOX_SHIPPING', 'Shipping &amp; Returns');
  define('MODULE_BOXES_INFORMATION_BOX_CONTACT', 'Contact Us');
?>
