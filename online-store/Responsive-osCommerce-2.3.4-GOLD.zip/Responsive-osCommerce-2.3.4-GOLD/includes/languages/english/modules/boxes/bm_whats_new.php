<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_WHATS_NEW_TITLE', 'What\'s New');
  define('MODULE_BOXES_WHATS_NEW_DESCRIPTION', 'Show the newest products');
  define('MODULE_BOXES_WHATS_NEW_BOX_TITLE', 'What\'s New?');
?>
