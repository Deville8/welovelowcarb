<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_PRODUCT_COLORBOX_TITLE', 'Colorbox Script');
  define('MODULE_HEADER_TAGS_PRODUCT_COLORBOX_DESCRIPTION', 'Add Colorbox Script to specified pages');
?>
