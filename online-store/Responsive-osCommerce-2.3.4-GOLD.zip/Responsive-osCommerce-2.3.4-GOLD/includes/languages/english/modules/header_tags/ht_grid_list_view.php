<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_GRID_LIST_VIEW_TITLE', 'Grid List Javascript (jQuery)');
  define('MODULE_HEADER_TAGS_GRID_LIST_VIEW_DESCRIPTION', 'Add Grid List javascript to specified pages, which invokes a Grid/List view for product lists');

