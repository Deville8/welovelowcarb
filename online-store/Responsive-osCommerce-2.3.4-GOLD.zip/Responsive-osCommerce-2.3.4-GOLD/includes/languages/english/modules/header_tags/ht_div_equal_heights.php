<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_HEADER_TAGS_DIV_EQUAL_HEIGHTS_TITLE', 'Equal Height Divs (jQuery)');
  define('MODULE_HEADER_TAGS_DIV_EQUAL_HEIGHTS_DESCRIPTION', 'Add Equal Heights javascript to specified pages, which solves a potential problem in grid layouts');

