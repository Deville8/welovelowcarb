<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_FOOTER_CONTACT_US_TITLE', 'Contact Us Details');
  define('MODULE_CONTENT_FOOTER_CONTACT_US_DESCRIPTION', 'Adds a Contact Us Block to the Footer Area of your site');

  define('MODULE_CONTENT_FOOTER_CONTACT_US_HEADING_TITLE', 'How To Contact Us');
  define('MODULE_CONTENT_FOOTER_CONTACT_US_EMAIL_LINK', 'Contact Us');

