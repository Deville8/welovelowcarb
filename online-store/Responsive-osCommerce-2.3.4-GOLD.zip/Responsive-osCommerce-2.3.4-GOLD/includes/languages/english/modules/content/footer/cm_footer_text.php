<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_FOOTER_TEXT_TITLE', 'Text Block');
  define('MODULE_CONTENT_FOOTER_TEXT_DESCRIPTION', 'Adds a Text Block to the Footer Area of your site');

  define('MODULE_CONTENT_FOOTER_TEXT_HEADING_TITLE', 'About Us');


  define('MODULE_CONTENT_FOOTER_TEXT_TEXT', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>');

