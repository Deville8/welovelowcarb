<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_HEADER_LOGO_TITLE', 'Logo');
  define('MODULE_CONTENT_HEADER_LOGO_DESCRIPTION', 'Adds your Logo into the Header Area of your site.');

