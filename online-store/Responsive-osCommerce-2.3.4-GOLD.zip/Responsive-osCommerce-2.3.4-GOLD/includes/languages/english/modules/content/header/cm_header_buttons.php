<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_HEADER_BUTTONS_TITLE', 'Buttons');
  define('MODULE_CONTENT_HEADER_BUTTONS_DESCRIPTION', 'Adds Login/Checkout Buttons into the Header Area of your site.');

