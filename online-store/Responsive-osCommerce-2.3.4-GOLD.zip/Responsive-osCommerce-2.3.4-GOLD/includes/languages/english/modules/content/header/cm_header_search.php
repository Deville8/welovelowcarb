<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_HEADER_SEARCH_TITLE', 'Search Box');
  define('MODULE_CONTENT_HEADER_SEARCH_DESCRIPTION', 'Adds your Search Box into the Header Area of your site.');

