<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_PRODUCT_INFO_REVIEWS_TITLE', 'Product Reviews');
  define('MODULE_CONTENT_PRODUCT_INFO_REVIEWS_DESCRIPTION', 'Show review block on the product info page.');
  
  define('MODULE_CONTENT_PRODUCT_INFO_REVIEWS_TEXT_RATED', 'Rated %s by <cite title="%s">%s</cite>');

