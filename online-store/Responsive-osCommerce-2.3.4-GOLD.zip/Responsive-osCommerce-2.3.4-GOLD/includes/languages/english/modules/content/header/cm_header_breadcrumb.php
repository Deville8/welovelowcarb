<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_HEADER_BREADCRUMB_TITLE', 'Breadcrumb');
  define('MODULE_CONTENT_HEADER_BREADCRUMB_DESCRIPTION', 'Adds a Breadrcumb Trail into the Header Area of your site.');

