<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_FOOTER_INFORMATION_TITLE', 'Information Links Block');
  define('MODULE_CONTENT_FOOTER_INFORMATION_DESCRIPTION', 'Adds Information Links Block to the Footer Area of your site');

  define('MODULE_CONTENT_FOOTER_INFORMATION_HEADING_TITLE', 'Information');

  define('MODULE_CONTENT_FOOTER_INFORMATION_SHIPPING', 'Shipping & Returns');
  define('MODULE_CONTENT_FOOTER_INFORMATION_PRIVACY', 'Privacy & Cookie Policy');
  define('MODULE_CONTENT_FOOTER_INFORMATION_CONDITIONS', 'Terms & Conditions');
  define('MODULE_CONTENT_FOOTER_INFORMATION_CONTACT', 'Contact Us');

