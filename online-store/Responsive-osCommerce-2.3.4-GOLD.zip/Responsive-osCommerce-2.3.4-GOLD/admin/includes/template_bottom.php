<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/
?>

</div>

<?php require(DIR_WS_INCLUDES . 'footer.php'); ?>

<br />

</body>
</html>
