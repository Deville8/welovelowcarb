<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Security Directory Permissions');

define('TABLE_HEADING_DIRECTORIES', 'Directories');
define('TABLE_HEADING_WRITABLE', 'Writable');
define('TABLE_HEADING_RECOMMENDED', 'Recommended');

define('TEXT_DIRECTORY', 'Directory:');
?>
