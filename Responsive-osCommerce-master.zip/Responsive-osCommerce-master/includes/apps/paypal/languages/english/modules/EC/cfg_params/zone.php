cfg_ec_zone_title = Payment Zone
cfg_ec_zone_desc = Enable this payment module globally or limit it to customers shipping to the selected zone only.

cfg_ec_zone_global = -- Global --
