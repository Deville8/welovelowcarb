cfg_ps_ewp_public_cert_title = Your Public Certificate
cfg_ps_ewp_public_cert_desc = The location and filename of your Public Certificate to use for encrpyting the parameters. (*.pem)
