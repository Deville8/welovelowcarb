cfg_ec_checkout_flow_title = Checkout Flow
cfg_ec_checkout_flow_desc = Set this to Default to have PayPal automatically choose the best checkout flow to use, or to use the new In-Context checkout flow (beta).<br /><br /><em>In-Context only works in certain conditions and automatically disables Instant Update.</em>

cfg_ec_checkout_flow_default = Default
cfg_ec_checkout_flow_in_context = In-Context (Beta)
