cfg_ps_ewp_status_title = Encrypted Website Payments
cfg_ps_ewp_status_desc = Set this to True to encrypt the transaction parameters sent to PayPal with your private key and certificate.

cfg_ps_ewp_status_true = True
cfg_ps_ewp_status_false = False
