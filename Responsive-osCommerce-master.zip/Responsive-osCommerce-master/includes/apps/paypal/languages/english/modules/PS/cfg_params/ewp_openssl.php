cfg_ps_ewp_openssl_title = OpenSSL Location
cfg_ps_ewp_openssl_desc = The location and filename of the openssl binary file.
