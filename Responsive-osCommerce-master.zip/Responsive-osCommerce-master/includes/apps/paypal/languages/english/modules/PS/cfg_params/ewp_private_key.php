cfg_ps_ewp_private_key_title = Your Private Key
cfg_ps_ewp_private_key_desc = The location and filename of your Private Key to use for encrypting the parameters. (*.pem)
