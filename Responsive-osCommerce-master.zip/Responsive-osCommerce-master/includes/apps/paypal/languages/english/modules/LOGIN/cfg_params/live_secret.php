cfg_login_live_secret_title = Live Secret
cfg_login_live_secret_desc = The Secret of the PayPal REST App Live Credentials.
