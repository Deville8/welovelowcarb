cfg_login_content_width_title = Content Width
cfg_login_content_width_desc = Should the content be shown in a full or half width container?

cfg_login_content_width_half = Half
cfg_login_content_width_full = Full
