cfg_ps_page_style_title = Page Style
cfg_ps_page_style_desc = Add the Page Style defined in your PayPal account profile to apply the style to the checkout flow.
