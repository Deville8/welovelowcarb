cfg_login_status_title = Status
cfg_login_status_desc = Set this to Live to use the Live REST API credentials or to Test to use the Test credentials.

cfg_login_status_live = Live
cfg_login_status_test = Test
cfg_login_status_disabled = Disabled
