cfg_login_theme_title = Theme
cfg_login_theme_desc = The theme to use for the style of the login button.

cfg_login_theme_blue = Blue
cfg_login_theme_neutral = Neutral
