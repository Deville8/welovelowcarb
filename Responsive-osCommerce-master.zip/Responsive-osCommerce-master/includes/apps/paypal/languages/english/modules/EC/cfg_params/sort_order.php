cfg_ec_sort_order_title = Sort Order
cfg_ec_sort_order_desc = The sort order location of the module shown in the available payment methods listing (lowest is displayed first).
