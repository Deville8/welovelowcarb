section_general = General
section_more = +

dialog_uninstall_title = Uninstall Module?
dialog_uninstall_body = Are you sure you want to uninstall this module?

alert_module_install_success = Module has been successfully installed.
alert_module_uninstall_success = Module has been successfully uninstalled.
alert_cfg_saved_success = Configuration parameters have been successfully saved.
