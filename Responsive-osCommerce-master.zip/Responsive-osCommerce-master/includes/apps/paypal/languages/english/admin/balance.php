heading_live_account = Live: :account
heading_sandbox_account = Sandbox: :account

retrieving_balance_progress = Retrieving balance &hellip;

error_no_accounts_configured = Error: No PayPal Live or Sandbox account has yet been configured. Please set up a PayPal account and try again.
error_balance_retrieval = Error: The PayPal balance could not be retrieved. Please try again.
