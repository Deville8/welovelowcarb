online_documentation_title = Online Documentation

online_documentation_body = <p>Online documentation is available at the osCommerce Library website:</p>
<p>:button_online_documentation</p>

button_online_documentation = Online Documentation

online_forum_title = Online Forum

online_forum_body = <p>Support enquiries can be posted at the osCommerce Support Forum PayPal Channel:</p>
<p>:button_online_forum</p>

button_online_forum = osCommerce Support Forums
