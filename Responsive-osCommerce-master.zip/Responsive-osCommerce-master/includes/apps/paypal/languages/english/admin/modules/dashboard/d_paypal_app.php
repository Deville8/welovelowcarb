module_admin_dashboard_title = PayPal App
module_admin_dashboard_description = PayPal App Dashboard module to display the PayPal balance and new app version update notifications.

heading_live_account = PayPal Live: :account
heading_sandbox_account = PayPal Sandbox: :account

button_app_get_started = Get Started with the PayPal App
button_view_update = View Update

update_available_body = <p>An update is available for the PayPal App!</p>
<p><small>:button_view_update</small></p>
