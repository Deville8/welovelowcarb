cfg_gateway_title = Gateway
cfg_gateway_desc = Set this to the gateway to use to process payments through.

cfg_gateway_paypal = PayPal
cfg_gateway_payflow = Payflow
