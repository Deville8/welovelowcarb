cfg_log_transactions_title = Log Transactions
cfg_log_transactions_desc = Set this to the level of transactions that should be logged.

cfg_log_transactions_all = All
cfg_log_transactions_errors = Errors
cfg_log_transactions_disabled = Disabled
