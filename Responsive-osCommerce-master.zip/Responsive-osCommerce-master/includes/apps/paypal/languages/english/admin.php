app_link_info = Info/Help
app_link_privacy = Privacy

button_retrieve_live_credentials = Retrieve Live Credentials
button_retrieve_sandbox_credentials = Retrieve Sandbox Credentials

button_back = Back
button_cancel = Cancel
button_delete = Delete
button_dialog_delete = Delete &hellip;
button_install = Install
button_install_title = Install :title
button_save = Save
button_uninstall = Uninstall
button_dialog_uninstall = Uninstall &hellip;
button_view = View
button_view_update = View Update

update_available_body = <p>An update is available for this App!</p>
<p><small>:button_view_update</small></p>
