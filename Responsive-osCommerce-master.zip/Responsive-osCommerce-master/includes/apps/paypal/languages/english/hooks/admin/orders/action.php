ms_success_getTransactionDetails = Details of the PayPal transaction have been successfully retrieved.
ms_error_getTransactionDetails = A problem occurred while retrieving details of the PayPal transaction. Please check the PayPal App Log for more information.

ms_success_doCapture = The PayPal transaction has been successfully captured.
ms_error_doCapture = A problem occurred while capturing the PayPal transaction. Please check the PayPal App Log for more information.

ms_success_doVoid = The PayPal transaction has been successfully cancelled.
ms_error_doVoid = A problem occurred while cancelling the PayPal transaction. Please check the PayPal App Log for more information.

ms_success_refundTransaction = The PayPal transaction has been successfully refunded (:refund_amount).
ms_error_refundTransaction = A problem occurred while refunding the PayPal transaction (:refund_amount). Please check the PayPal App Log for more information.
