button_dialog_capture = Capture &hellip;
button_details = Details
button_dialog_refund = Refund &hellip;
button_view_at_paypal = View at PayPal
button_dialog_void = Void &hellip;

tab_title = PayPal

dialog_capture_title = Capture Payment
dialog_capture_body = The full or a partial amount can be captured.
dialog_capture_amount_field_title = Amount:
dialog_capture_last_capture_field_title = This is the last capture (release <span id="ppCaptureVoidedValue"></span> :currency back to the customer).
dialog_capture_button_capture = Capture Amount
dialog_capture_button_cancel = Cancel

dialog_void_title = Void Payment
dialog_void_body = Are you sure you want to void the authorized payment?
dialog_void_button_void = Void Payment
dialog_void_button_cancel = Cancel

dialog_refund_title = Refund Payment
dialog_refund_body = Please select which refunds to perform:
dialog_refund_payment_title = Refund :amount to customer.
dialog_refund_button_refund = Refund Payment
dialog_refund_button_cancel = Cancel
